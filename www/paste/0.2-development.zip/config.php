
<?php/*
	config.php
	Part of the Open Pastebin project - version 0.2-development
	10/8/2004
	Ville S�rkk�l� - villeveikko@users.sourceforge.net

	Configuration file.

	Released under GNU GENERAL PUBLIC LICENSE
	Version 2, June 1991 -  or later
*/?>

<?php
    // MySQL variables
    $mysql_server = "localhost:3306";
    $mysql_username = "anon";
    $mysql_password = "";
    $mysql_dbname = "opbdb";
?>
